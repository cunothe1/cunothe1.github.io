Installation

1 Extract deze zip in een map naar keuze
   1.1 maak een map aan
   1.2 extraxt hier alle bestanden

2 verplaats de "game" folder naar AppData/local/
   2.1 tik in %AppData% in de adresbalk
   2.2 ga een map omhoog, dus naar de Appdata map
   2.3 selecteer daar local
   2.4 plaats hier de map

3 edit de settings
   3.1 ga naar de game map in appdata/local/
   3.2 open settings.ini met notepad
   3.3 edit variabelen
      AI [0/1] bepaal of dit een player(0) of een bot (1) is
      slots1-9 [5/6/12] bepaal wapen loadout, railgun5 laser6 raket12
   3.4 opslaan

4 play the game
   4.1 klik op de .exe file in de map van stap 1
   4.2 een uitleg:
      Je kan schepen spawnen met pijltjes links en rechts
      rechts is playerleft en links is playerright
      als een team ai uit heeft staan, dan kan je die schepen
      selecteren. met shift kan je er meerdere selecteren
      je mikt naar de muis en schiet met q,w,e, die staan voor
      railguns, lasers, raketten respectievelijk.